import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, 'server_database.json');

// ✅ FIX: مدة بقاء الـ claim في الذاكرة قبل ما يتنضف (نفس القديمة: دقيقتين)
const AI_CLAIM_TTL_MS = 120_000;
// تنظيف دوري كل دقيقة عشان الـ Map ما تكبرش بلا حدود
const AI_CLAIM_CLEANUP_INTERVAL_MS = 60_000;

class Database {
  constructor() {
    this.data = this.load();

    // ✅ FIX: aiMessageClaims بقت Map في الذاكرة بدل read/write كامل لملف
    //   الداتابيس في كل رسالة AI (كانت بتعمل fs.readFileSync + fs.writeFileSync sync
    //   على الملف كله — ده blocking على الـ event loop ومش آمن لو رسالتين جم
    //   في نفس اللحظة بالظبط). دلوقتي كل العملية في الذاكرة، وبتتحفظ تلقائيًا
    //   مع باقي البيانات في save() العادية بدل عمليات I/O منفصلة.
    this.aiMessageClaims = new Map();

    // ✅ backward-compat: لو فيه claims قديمة محفوظة في الملف من نسخة سابقة
    //   (سواء aiClaims القديمة أو aiMessageClaims الجديدة)، نحمّلها للـ Map
    //   مع تجاهل أي حاجة أقدم من TTL
    const now = Date.now();
    const legacyClaims = this.data.aiMessageClaims || this.data.aiClaims || {};
    for (const [msgId, ts] of Object.entries(legacyClaims)) {
      if (typeof ts === "number" && now - ts < AI_CLAIM_TTL_MS) {
        this.aiMessageClaims.set(msgId, ts);
      }
    }
    // شيل المفتاح القديم aiClaims نهائيًا — بقى aiMessageClaims بس
    delete this.data.aiClaims;

    // ✅ تنظيف دوري للـ entries الأقدم من AI_CLAIM_TTL_MS (زي ما كان موجود في القديم)
    this._aiClaimsCleanupInterval = setInterval(() => {
      this._cleanupAiMessageClaims();
    }, AI_CLAIM_CLEANUP_INTERVAL_MS);
    this._aiClaimsCleanupInterval.unref?.(); // ما يمنعش الـ process من القفل

    // أول تنظيف فوري عشان نبدأ نضيفين من القديم لو فيه حاجة منتهية
    this._cleanupAiMessageClaims();
  }

  load() {
    try {
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, 'utf8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.warn('⚠️ ما تقدرتش أقراي الداتابيس، بنبدأ من الصفر');
    }

    return {
      users: {},
      warnings: {},
      manhwa: {},
      welcome: {},
      suggestions: {},
      modLogs: {},
      spamTracking: {},
      raidTracking: {}
    };
  }

  // ✅ FIX: بنحط الـ Map في this.data قبل الحفظ عشان تتحفظ مع باقي البيانات
  //   في نفس عملية الكتابة العادية، بدون أي fs call إضافي منفصل
  save() {
    try {
      if (this.aiMessageClaims) {
        this.data.aiMessageClaims = Object.fromEntries(this.aiMessageClaims);
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(this.data, null, 2), 'utf8');
    } catch (err) {
      console.error('❌ ما تقدرتش أحفظ الداتابيس:', err.message);
    }
  }

  ensureUser(userId) {
    if (!this.data.users[userId]) {
      this.data.users[userId] = {
        xp: 0,
        level: 0,
        coins: 0,
        lastDaily: null,
        warnings: [],
        timeouts: [],
        bankCoins: 0,
        lastBankInterest: 0,
      };
      this.save();
    }
    if (typeof this.data.users[userId].bankCoins !== "number") this.data.users[userId].bankCoins = 0;
    if (typeof this.data.users[userId].lastBankInterest !== "number") this.data.users[userId].lastBankInterest = 0;
    return this.data.users[userId];
  }

  getUser(userId) {
    return this.ensureUser(userId);
  }

  updateUser(userId, updates) {
    const user = this.ensureUser(userId);
    Object.assign(user, updates);
    this.save();
    return user;
  }

  addWarning(userId, reason, moderator = 'SYSTEM') {
    this.ensureUser(userId);
    if (!this.data.users[userId].warnings) {
      this.data.users[userId].warnings = [];
    }

    this.data.users[userId].warnings.push({
      reason,
      moderator,
      timestamp: Date.now()
    });
    this.save();
  }

  getWarnings(userId) {
    this.ensureUser(userId);
    return this.data.users[userId].warnings || [];
  }

  addTimeout(userId, duration, reason) {
    this.ensureUser(userId);
    if (!this.data.users[userId].timeouts) {
      this.data.users[userId].timeouts = [];
    }

    this.data.users[userId].timeouts.push({
      duration,
      reason,
      timestamp: Date.now()
    });
    this.save();
  }

  getGuildConfig(guildId) {
    if (!this.data.welcome) {
      this.data.welcome = {};
    }
    return this.data.welcome[guildId] || null;
  }

  setWelcomeChannel(guildId, channelId) {
    this.data.welcome[guildId] = channelId;
    this.save();
  }

  addManhwaTerm(dictName, term, translation) {
    if (!this.data.manhwa[dictName]) {
      this.data.manhwa[dictName] = {};
    }
    this.data.manhwa[dictName][term] = translation;
    this.save();
  }

  getManhwaDict(dictName) {
    return this.data.manhwa[dictName] || {};
  }

  getAllManhwaDicts() {
    return this.data.manhwa;
  }

  trackSpam(guildId, userId) {
    const key = `${guildId}-${userId}`;
    if (!this.data.spamTracking[key]) {
      this.data.spamTracking[key] = {
        count: 0,
        firstMessageTime: Date.now()
      };
    }
    this.data.spamTracking[key].count++;
    return this.data.spamTracking[key];
  }

  resetSpamTracker(guildId, userId) {
    const key = `${guildId}-${userId}`;
    if (this.data.spamTracking[key]) {
      delete this.data.spamTracking[key];
    }
  }

  trackRaid(guildId, userId) {
    const key = `${guildId}-raid`;
    if (!this.data.raidTracking[key]) {
      this.data.raidTracking[key] = {
        joinTimes: []
      };
    }
    this.data.raidTracking[key].joinTimes.push(Date.now());

    // Keep only recent joins (within last 60 seconds)
    const now = Date.now();
    this.data.raidTracking[key].joinTimes = this.data.raidTracking[key].joinTimes.filter(
      (t) => now - t < 60000
    );

    return this.data.raidTracking[key];
  }

  getRaidJoinCount(guildId, windowMs) {
    const key = `${guildId}-raid`;
    if (!this.data.raidTracking[key]) {
      return 0;
    }

    const now = Date.now();
    return this.data.raidTracking[key].joinTimes.filter((t) => now - t < windowMs).length;
  }

  // ─── حماية من الرد المكرر بين نسختين للبوت ──────────────────
  // ✅ FIX: بقت كلها في الذاكرة (Map) بدل readFileSync/writeFileSync على
  //   ملف الداتابيس كله في كل رسالة AI. ده بيشيل الـ blocking I/O والـ
  //   race condition اللي كان ممكن يحصل لو رسالتين جم في نفس اللحظة بالظبط.
  //   ⚠️ ملحوظة: ده حل لمشكلة الأداء/الـ race داخل نفس العملية (single instance).
  //   لو شغال نسختين من البوت في نفس الوقت (multi-instance على Replit مثلاً)،
  //   النظام ده مش هيحمي من تكرار الردود بين النسختين لأنه في الذاكرة بس —
  //   محتاج نظام تنسيق عبر الـ disk (زي ClaimStore) للحالة دي.
  claimAiMessage(msgId) {
    const now = Date.now();

    const existing = this.aiMessageClaims.get(msgId);
    if (existing !== undefined && now - existing < AI_CLAIM_TTL_MS) {
      return false; // اتكلّم عليه قبل كده ولسه ضمن الـ TTL
    }

    this.aiMessageClaims.set(msgId, now);
    return true;
  }

  // ✅ FIX: تنظيف دوري للـ claims الأقدم من AI_CLAIM_TTL_MS (دقيقتين)
  //   عشان الـ Map ما تكبرش بلا حدود مع الوقت
  _cleanupAiMessageClaims() {
    const now = Date.now();
    for (const [msgId, ts] of this.aiMessageClaims) {
      if (now - ts >= AI_CLAIM_TTL_MS) {
        this.aiMessageClaims.delete(msgId);
      }
    }
  }

  // ─── قدرات الألعاب ───────────────────────────────────────────
  getGameAbilities(userId) {
    const user = this.ensureUser(userId);
    if (!user.gameAbilities) { user.gameAbilities = {}; this.save(); }
    return user.gameAbilities;
  }

  hasGameAbility(userId, type) {
    return (this.getGameAbilities(userId)[type] || 0) > 0;
  }

  addGameAbility(userId, type, count = 1) {
    const a = this.getGameAbilities(userId);
    a[type] = (a[type] || 0) + count;
    this.save();
  }

  useGameAbility(userId, type) {
    const a = this.getGameAbilities(userId);
    if (!a[type] || a[type] <= 0) return false;
    a[type]--;
    if (a[type] === 0) delete a[type];
    this.save();
    return true;
  }

  getAllData() {
    return this.data;
  }

  // ─── 🌍 لعبة الحياة (نظام اقتصادي شخصي مستمر، per-guild) ──────
  // ✅ مستقل بالكامل عن users[userId].coins — بروفايل اللعبة الجديدة
  //   بيبدأ من الصفر لما اليوزر يلعب لأول مرة، ومحلي لكل سيرفر لوحده
  //   (نفس اليوزر في سيرفرين مختلفين = بروفايلين مختلفين تمامًا)
  ensureLifeProfile(guildId, userId) {
    if (!this.data.lifeProfiles) this.data.lifeProfiles = {};
    if (!this.data.lifeProfiles[guildId]) this.data.lifeProfiles[guildId] = {};

    if (!this.data.lifeProfiles[guildId][userId]) {
      this.data.lifeProfiles[guildId][userId] = {
        coins: 0,
        jobLevel: 0,        // 0 = بدون وظيفة
        jobSince: null,     // وقت بداية الوظيفة الحالية (لحساب الخبرة)
        assets: { house: false, car: false, company: false },
        debt: 0,            // قيمة موجبة = مديون
        debtSince: null,    // وقت أول ما الدين بدأ
        debtWarned: false,  // اتبعتله إنذار قبل كده؟
        health: 100,
        lastTick: Date.now(),
        createdAt: Date.now(),
      };
      this.save();
    }

    const p = this.data.lifeProfiles[guildId][userId];
    // backward-safety: لو فيه بروفايل قديم من نسخة تجريبية وناقصه حقل
    if (typeof p.coins !== "number") p.coins = 0;
    if (typeof p.jobLevel !== "number") p.jobLevel = 0;
    if (!p.assets) p.assets = { house: false, car: false, company: false };
    if (typeof p.debt !== "number") p.debt = 0;
    if (typeof p.health !== "number") p.health = 100;
    if (typeof p.lastTick !== "number") p.lastTick = Date.now();
    // ✅ migration: لو فيه بروفايل قديم من نسخة تجريبية كانت بمنطق "محفظة
    //   سالبة = دين" (قبل ما نفصل المحفظة عن الدين)، نحوّل أي رصيد سالب
    //   لدين فعلي ونصفّر المحفظة، عشان النظام الجديد يفضل متّسق دايمًا
    if (p.coins < 0) {
      p.debt += -p.coins;
      p.coins = 0;
      if (!p.debtSince) p.debtSince = Date.now();
    }

    return p;
  }

  getLifeProfile(guildId, userId) {
    return this.ensureLifeProfile(guildId, userId);
  }

  getGuildLifeProfiles(guildId) {
    if (!this.data.lifeProfiles || !this.data.lifeProfiles[guildId]) return {};
    return this.data.lifeProfiles[guildId];
  }

  // ─── قائمة الباند ────────────────────────────────────────────
  addBan(userId, reason, moderatorId = 'SYSTEM') {
    if (!this.data.banList) this.data.banList = {};
    this.data.banList[userId] = {
      userId,
      reason,
      moderatorId,
      timestamp: Date.now(),
    };
    this.save();
  }

  removeBan(userId) {
    if (!this.data.banList) return false;
    if (!this.data.banList[userId]) return false;
    delete this.data.banList[userId];
    this.save();
    return true;
  }

  getBanList() {
    if (!this.data.banList) this.data.banList = {};
    return this.data.banList;
  }

  isBanned(userId) {
    return !!(this.data.banList && this.data.banList[userId]);
  }

  clearOldData(maxAge = 86400000) {
    // Clear spam tracking after 24 hours
    const now = Date.now();
    for (const key in this.data.spamTracking) {
      if (now - this.data.spamTracking[key].firstMessageTime > maxAge) {
        delete this.data.spamTracking[key];
      }
    }
    this.save();
  }
}

export default Database;
